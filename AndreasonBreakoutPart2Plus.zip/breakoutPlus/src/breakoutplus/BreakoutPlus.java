package breakoutplus;

/* 
    Project 2 Part 2 - Breakout
    The classic game where you break bricks with a ball and paddle.
    Jeremy Andreason
    3/22/2021

	This version is my attempt at extra credit through improvements to the base-level program assignment.
	Changes I have made include:
	1. Score displayed as well as turns remaining.
	2. Different colored bricks, worth more points as you get further from the paddle. (Bottom row color worth less than top row color)
	3. Ball launches from paddle, huge gameplay improvement in my opinion, especially with the nature of the popup window when you click run.
	4. Ball trajectory influenced by where on the paddle it hits, as opposed to just behaving as if it bounced off the bottom wall, basically.
	5. Ball increases in speed for ever 20 times it contacts the paddle until a maximum of four speed increases. This speed resets upon a lost ball.
	6. Paddle stops being attached to cursor after the game ends (this bothered me for some reason).
	Maybe other small things that I don't super remember.
*/

import acm.graphics.*;
import acm.program.*;
import java.awt.*;
import java.awt.event.*;

public class BreakoutPlus extends GraphicsProgram
{
    final String TITLE       = "Breakout!";
    final int WINDOW_WIDTH   = 700;
    final int WINDOW_HEIGHT  = 900;
    final int BRICK_ROWS     = 10;
    final int BRICK_COLUMNS  = 10;
    final int PADDLE_WIDTH   = 100;
    final int PADDLE_HEIGHT  = 20;
    final int BALL_DIAMETER  = 20;
    final int BALL_SPEED     = 5;
	final int MIN_RUN_DELAY  = 2;	// this value is the minimum delay AKA the fastest the ball can go
	final int MAX_RUN_DELAY  = 5;	// thiss is the opposite of above line (slowest it goes, also the base speed)
    final int GAME_HEIGHT    = 825;
    final int GAME_WIDTH     = 672;
	final int VOLLEY         = 20;   // this value determines how many paddle hits to increase ball speed
	final double VELOCITY    = 3;	 // needed a velocity constant to fix bug with ball rolling on surfaces instead of bouncing
    final Color PADDLE_COLOR = Color.LIGHT_GRAY;
    final Color BALL_COLOR   = Color.MAGENTA;
	final Color WINDOW_BACKGROUND = Color.DARK_GRAY;
	final Color[] BRICK_COLORS = {Color.BLUE, Color.RED, Color.YELLOW, Color.CYAN, Color.GREEN}; // brick color array handled with if statement later
	final String WIN  = "You Won :(";
	final String LOSE = "YOU'RE A LOSER";
	final String FONT = "Times";
	final String FONT_WIN_LOSE = "Times-28";
	double ballX;
    double ballY;
    double xVelocity = VELOCITY;
    double yVelocity = VELOCITY;
	int brickCount = BRICK_ROWS * BRICK_COLUMNS;
	int turns = 3;
	int score = 0;
	int runDelay = MAX_RUN_DELAY;
	int paddleHits = 0;
	boolean waitingToServe = false;	// in order to get the ball to sit on paddle until you click, when this is true 
	String score2 = "Score: ";
    GRect brick;
    GRect paddle;
    GOval ball;
    GLine bottomWall, topWall, leftWall, rightWall;
	GLabel info;
    
	
    public static void main(String[] args) 
    {
        new BreakoutPlus().start();
    }
    
    @Override
    public void init() 
    {
		/*
			the menu bar was bugging with the mouse click event. When first opening the program it doesn't load until you've clicked once,
			shifting the screen when you launch the first ball. Couldn't figure out a different way to fix it so I removed the menu bar.
		*/
		getMenuBar().setVisible(false);
		// info is the HUD for score and lives, code self-explanatory
        info = new GLabel("");
		info.setColor(Color.WHITE);
		updateInfo();
		info.setFont(FONT);
		info.setLocation(7,20);
		add(info);
		
		/*
            draws four borders of the play area, the header of the window as well as the edges
            make the pixels pretty wonky and hard to deal with, thus the weird specific pixel values.
        */
        leftWall   = new GLine(5,5 + info.getHeight(),5,880);
        add(leftWall);
        rightWall  = new GLine(677,5 + info.getHeight(),677,880);
        add(rightWall);
        bottomWall = new GLine(5,880,677,880);
        add(bottomWall);
        topWall    = new GLine(5,5 + info.getHeight(),677,5 + info.getHeight());
        add(topWall);
        
        /*
            Sets the size and title of the popup window when running the program.
        */
        setSize (WINDOW_WIDTH,WINDOW_HEIGHT);
        setTitle(TITLE);
        setBackground(WINDOW_BACKGROUND);
        /*
            draws paddle, colors it. Initial placement is center of play area X, adjusted for paddle width.
        */
        paddle = new GRect((GAME_WIDTH - PADDLE_WIDTH) / 2, bottomWall.getY() - (PADDLE_HEIGHT + 50), PADDLE_WIDTH, PADDLE_HEIGHT);
        paddle.setFilled(true);
        paddle.setColor(PADDLE_COLOR);
        add(paddle);
        
        /*
            draws ball, colors it. Initial placement is center of play area X and Y, adjusted for ball diameter.
        */
        ball = new GOval((paddle.getX() + (PADDLE_WIDTH - BALL_DIAMETER) / 2), paddle.getY() - BALL_DIAMETER, BALL_DIAMETER, BALL_DIAMETER);
        ball.setFilled(true);
        ball.setColor(BALL_COLOR);
        add(ball);

        /*
            brickWidth is set to be a fraction of the play area, adjusted for the
            gap between each brick. brickHeight is set to be 1/3rd the width, adjusted
            for the gap between each brick. brickX and Y are set to the X and Y of
            the left and top walls, adjusted for gap between wall and outside-most
            bricks.
        */
        double brickWidth = GAME_WIDTH / BRICK_COLUMNS - 5;
        double brickHeight = brickWidth / 3 - 5;
        double brickX = leftWall.getX() + 4;
        double brickY = topWall.getY() + 50;
        
        /*
            Nested for-loop, draws a brick at brickX and then adds one tenth the
            play area's width to brickX, repeats 10 times, leaving 10 bricks in
            a row, filling the play area between the left and right wall.
            
            After each row, the outside loop drops the Y down one brick height(adjusted
            for the gap) and starts the inside loop again. This outside loop repeats
            for a total of 10 iterations, leaving 10 rows.
        */
		Color brickColor = BRICK_COLORS[0];
        for (int i = 0; i < BRICK_ROWS; i++)
        {
            for (int j = 0; j < BRICK_COLUMNS; j++)
            {
				if (i >= 2 && i % 2 == 0)
				{
					brickColor = BRICK_COLORS[i / 2 % BRICK_COLORS.length];
				}
                brick = new GRect (brickX, brickY, brickWidth, brickHeight);
                brickX += GAME_WIDTH / 10;
                brick.setFilled(true);
                brick.setColor(brickColor);
                add(brick);
            }
            
            brickY += brickWidth / 3;
            brickX = leftWall.getX() + 4;
        }
	    
        addMouseListeners();
		// Added these 3 lines to get the first ball serve to start from the paddle and require a left-click
		waitingToServe = true;
		waitForClick();
		waitingToServe = false;
    }
    
    @Override
    public void mouseMoved(MouseEvent me)
    {
		// basically if the game is over, jump out of this method. 
		// This if-statement's purpose is to stop the paddle from following the cursor.
		if(brickCount == 0 || turns == 0)
			return;
        
        /*
            currX is assigned to the x value of the mouse cursor, adjusted for
            the midpoint of the paddle. The paddle has it's location set to the
            mouse cursor X location, and it's own Y (as in Y is unchanged).
            Two if statements keep the paddle in bounds, by setting it's location,
            adjusted for paddle width, to the right and left walls' X values while
            the cursor is out of bounds.
        */
        double currX = me.getX() - (PADDLE_WIDTH / 2);
        
        if (currX < leftWall.getX())
            currX = leftWall.getX();
        
        if (currX > rightWall.getX() - PADDLE_WIDTH)
            currX = rightWall.getX() - PADDLE_WIDTH;
        
        paddle.setLocation(currX, paddle.getY());
		
		// whenever you lose a life, waitingToServe becomes true, and this resets the ball to the paddle
		if(waitingToServe)
		{
			ballX = (paddle.getX() + (PADDLE_WIDTH - BALL_DIAMETER) / 2);
			ballY = paddle.getY() - ball.getWidth();
			ball.setLocation(ballX,ballY);
		}
		
    }
    
    @Override
    public void run() 
    {
		GObject collision;
        
		//	loop runs while there are still bricks and lives remaining - ball x,y coordinates are retrieved		
        while (turns > 0 && brickCount > 0) 
        {
            ballX = ball.getX();
            ballY = ball.getY();
			// if-statement chain to see if any corner of the ball is touching an element, setting collision to null if they aren't
			collision = getElementAt(ballX,ballY);
			if (collision == null)
			{
				collision = getElementAt(ballX + BALL_DIAMETER,ballY);
				if (collision == null)
				{
					collision = getElementAt(ballX,ballY + BALL_DIAMETER);
					if (collision == null)
					{
						collision = getElementAt(ballX + BALL_DIAMETER,ballY + BALL_DIAMETER);
					}
				}
			}
			// in the base that collision is not null, this if statement executes
			if (collision != null)
			{
				// top, left, and right wall have their velocity sign flipped. (fixed ball rolling bug with VELOCITY constant)
				if (collision == topWall)
				{
					yVelocity = VELOCITY;
				}
				else if (collision == leftWall)
				{
					xVelocity = VELOCITY;
				}
				else if (collision == rightWall)
				{
					xVelocity = -VELOCITY;
				}
				/*
					when paddle registers a hit, the number of hits is incremented for the purpose of increasing ball speed every 20 hits,
					runDelay cannot go below the min, which is 2. (fixes bouncing ball off roof and missing bricks causing speed to go on forever
					theoretically
				*/
				else if (collision == paddle)
				{
					paddleHits++;
					if(paddleHits > VOLLEY && runDelay > MIN_RUN_DELAY)
					{
						runDelay--;
						paddleHits = 0;
					}
					
					/*
						when colliding with the paddle, xFactor is set to the difference between the midpoint of the ball and the midpoint
						of the paddle, divided by half of the paddle. 
					*/
					double ballMidX = ball.getX() + BALL_DIAMETER / 2;
					double paddleMidX = paddle.getX() + paddle.getWidth() / 2;
					double xFactor = (ballMidX - paddleMidX) / (paddle.getWidth() / 2);
					
					// keeps xFactor in the range of -1 to 1. Without this if and else if, the very edge of the paddle would cause overflow values
					if (xFactor > 1)
						xFactor = 1;
					else if (xFactor < -1)
						xFactor = -1;
					
					// the x velocity is multiplied by the xFactor to get different velocities depending on where the paddle is struck.
					// the y is reversed
					xVelocity = xFactor * VELOCITY;
					yVelocity = -VELOCITY;
				}
				// when colliding with the bottom wall the ball is reset to it's paddle position and the turns are deincremented (you lost a life)
				else if (collision == bottomWall)
				{
					yVelocity = 0;
					ballX = (paddle.getX() + (PADDLE_WIDTH - BALL_DIAMETER) / 2);
					ballY = paddle.getY() - ball.getWidth();
					ball.setLocation(ballX,ballY);
					turns--;
					updateInfo(); // calls the private function to update the information in the HUD to reflect the lost life
					
					/*
						colliding with the bottom wall but not losing the game, (still have turns) changes ball speed back to MAX_RUN_DELAY (slowest
						speed) and then changes boolean to true and waits for a click, at which point it reverts to false and the game continues.
					*/
					if (turns > 0)
					{
						runDelay = MAX_RUN_DELAY;
						paddleHits = 0;
						waitingToServe = true;
						waitForClick();
						waitingToServe = false;
					}
					
					/*
						otherwise, you've lost the game (no lives remain) and the ball is removed, the lose message is displayed.
					*/
					else
					{
						remove(ball);
						GLabel message = new GLabel(LOSE);
						message.setFont(FONT_WIN_LOSE);
						message.setLocation((getWidth() - message.getWidth()) / 2, (getHeight() - message.getHeight()) / 2);
						add(message);
					}
				}
				
				/*
					the final collision case handles bricks. yVelocity is reversed, and the brick is removed. Brick count is deincremented,
					in order to track the winning condition.
					If statement assigns the colors of the brick color array different point values, increasing as the colors get further from
					the paddle.
					Finally, the score is updated by calling the private updateInfo function, each time a brick is broken.
				*/
				else
				{
					yVelocity *= -1;
					remove(collision);
					brickCount--;
					if (collision.getColor() == BRICK_COLORS[0])
						score += 30;
					else if (collision.getColor() == BRICK_COLORS[1])
						score += 25;
					else if (collision.getColor() == BRICK_COLORS[2])
						score += 20;
					else if (collision.getColor() == BRICK_COLORS[3])
						score += 15;
					else if (collision.getColor() == BRICK_COLORS[4])
						score += 10;
					updateInfo();
					
					// the winning condition. When brickCount is zero the game is won. A message is displayed and the ball is removed.
					if (brickCount == 0)
					{
						remove(ball);
						GLabel message = new GLabel(WIN);
						message.setFont(FONT_WIN_LOSE);
						message.setLocation((getWidth() - message.getWidth()) / 2, (getHeight() - message.getHeight()) / 2);
						add(message);
					}
				}
			}
			
			// Ball velocity is added to ball x,y.
			ball.setLocation(ballX + xVelocity,ballY + yVelocity);
			// how fast the ball moves, depending on how many bounces off the paddle there have been in current turn.
			pause(runDelay);
        } 
    }
	
	/* 
		method to update the score and turns on the HUD. Many more methods could have been used but I am not fluent with these yet and
		I somewhat procrastinated. A good example of a method would have been resetting the ball to the paddle. I had to do that code maybe
		3 or 4 times and it looks clunky too.
	*/
	private void updateInfo()
	{
		info.setLabel(score2 + score + " \t Turns: " + turns);
	}
}
